package com.app.entities;

public enum Role {
	
	USER, ADMIN

}
